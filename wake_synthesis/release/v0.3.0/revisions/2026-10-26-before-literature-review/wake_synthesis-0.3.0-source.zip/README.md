# Uniqueness of the Classical Langton Ant Highway from Its Layer Profile

Local review source snapshot, version 0.3.0.
Run `python3 wake_synthesis/reproduce.py` from this directory.
Build: `make -C wake_synthesis/paper`.
The PDF is delivered separately. Historical release records and media exports
are omitted; proof sources, manuscript figures and verification evidence are included.
See the project README for exact dependencies and verification scope.
