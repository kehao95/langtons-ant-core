# Exact Escape Times of Langton's Ant in Four Rows

Local review source snapshot, version 0.1.0.
Run `python3 four_row_escape/reproduce.py` from this directory.
Build: `make -C four_row_escape/paper`.
The PDF is delivered separately. Historical release records and media exports
are omitted; proof sources, manuscript figures and verification evidence are included.
See the project README for exact dependencies and verification scope.
