# Finite-Memory Prediction and Remote Feedback in Langton’s Ant

Local review source snapshot, version 0.1.0.
Run `python3 memory_feedback/reproduce.py` from this directory.
Build: `make -C memory_feedback/paper`.
The PDF is delivered separately. Historical release records and media exports
are omitted; proof sources, manuscript figures and verification evidence are included.
See the project README for exact dependencies and verification scope.
