#!/usr/bin/env python3
"""Reproduce the four-cell certificates without changing retained evidence."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
CERTIFICATES = ('escapes.json', 'witness.json', 'report.json')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-report', type=Path)
    args = parser.parse_args()
    stages = []
    if sys.flags.optimize:
        raise SystemExit('Run without Python optimization (-O).')
    with tempfile.TemporaryDirectory(prefix='four-cell-port-') as directory:
        work = Path(directory)
        for source in (ROOT / 'verification').glob('*.py'):
            shutil.copy2(source, work / source.name)
        for name in CERTIFICATES:
            shutil.copy2(ROOT / 'evidence' / name, work / name)
        for name in ('check.py', 'independent.py'):
            result = subprocess.run([sys.executable, name], cwd=work,
                                    check=True, capture_output=True, text=True)
            print(f'{name}: {result.stdout.strip()}')
        for name in CERTIFICATES:
            original = (ROOT / 'evidence' / name).read_bytes()
            if (work / name).read_bytes() != original:
                raise SystemExit(f'Regenerated certificate differs: {name}')
            print(f'{name}: SHA256 {hashlib.sha256(original).hexdigest()} PASS')
        result = subprocess.run([sys.executable, 'audit.py', str(ROOT / 'evidence')],
                                cwd=work, check=True, capture_output=True, text=True)
        observed = json.loads(result.stdout)
        retained = json.loads((ROOT / 'evidence' / 'audit.json').read_text())
        if observed != retained or observed['status'] != 'PASS':
            raise SystemExit('Independent audit differs from retained results.')
        print('audit.py: 284 finite seeds, infinite cell certificates, mutation controls, '
              '96 exterior completions PASS')
    with tempfile.TemporaryDirectory(prefix='scattering-') as directory:
        work = Path(directory)
        imported = json.loads((ROOT/'evidence/import-2026-10-15.json').read_text())
        for entry in imported['files']:
            assert hashlib.sha256((ROOT/entry['destination']).read_bytes()).hexdigest() == entry['sha256']
        for module, retained in [('guarded_scattering', 'check_results.json'), ('return_scattering', 'report.json')]:
            shutil.copytree(ROOT/'verification'/module, work/module, ignore=shutil.ignore_patterns('__pycache__'))
            result = subprocess.run([sys.executable, 'check.py', '--compare', retained],
                                    cwd=work/module, capture_output=True, text=True)
            if result.returncode: raise RuntimeError(result.stdout+'\n'+result.stderr)
            stages.append({'module':module, 'status':'passed',
                           'retained_report':json.loads((work/module/retained).read_text())})
            print(module+': full exact replay PASS', flush=True)
    if args.output_report:
        args.output_report.write_text(json.dumps({'status':'passed','base_port_replayed':True,
            'stages':stages,'completed_utc':datetime.now(timezone.utc).isoformat()},indent=2)+'\n')
    print('FOUR-CELL PORTS AND COMPOSABLE SCATTERING: PASS')


if __name__ == '__main__':
    main()
