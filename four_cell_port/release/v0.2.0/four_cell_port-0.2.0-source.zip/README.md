# Four-Cell Ports and Composable Highway Scattering for Langton’s Ant

Local review source snapshot, version 0.2.0.
Run `python3 four_cell_port/reproduce.py` from this directory.
Build: `make -C four_cell_port/paper`.
The PDF is delivered separately. Historical release records and media exports
are omitted; proof sources, manuscript figures and verification evidence are included.
See the project README for exact dependencies and verification scope.
