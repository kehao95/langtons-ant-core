# Local Factor Rigidity and Mass–Defect Bounds for Langton’s Ant

Local review source snapshot, version 0.1.0.
Run `python3 factor_language/reproduce.py` from this directory.
Build: `make -C factor_language/paper`.
The PDF is delivered separately. Historical release records and media exports
are omitted; proof sources, manuscript figures and verification evidence are included.
See the project README for exact dependencies and verification scope.
